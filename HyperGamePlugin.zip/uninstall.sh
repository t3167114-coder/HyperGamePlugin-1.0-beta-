#!/system/bin/sh

###############################################################################
# AX EXTREME ENGINE
# UNINSTALL SCRIPT
###############################################################################

MODDIR="${0%/*}"

PLUGIN_NAME="AX Extreme Engine"

BASE_DIR="/data/local/tmp/ax_extreme"

LOG_FILE="$BASE_DIR/uninstall.log"

CPU_BACKUP="$BASE_DIR/cpu_governors"
GPU_BACKUP="$BASE_DIR/gpu_governors"


###############################################################################
# LOG
###############################################################################

log() {

    echo "[AX EXTREME] $1"

    if [ -d "$BASE_DIR" ]; then
        echo "[$(date '+%H:%M:%S')] $1" >> "$LOG_FILE" 2>/dev/null
    fi

}


###############################################################################
# RESTAURA CPU
###############################################################################

restore_cpu() {

    if [ ! -f "$CPU_BACKUP" ]; then

        log "Backup de CPU não encontrado."

        return

    fi


    log "Restaurando governors da CPU..."


    while IFS='|' read -r FILE VALUE; do

        if [ -n "$FILE" ] && [ -n "$VALUE" ]; then

            if [ -f "$FILE" ] && [ -w "$FILE" ]; then

                echo "$VALUE" > "$FILE" 2>/dev/null

                log "CPU restaurada: $FILE -> $VALUE"

            fi

        fi

    done < "$CPU_BACKUP"

}


###############################################################################
# RESTAURA GPU
###############################################################################

restore_gpu() {

    if [ ! -f "$GPU_BACKUP" ]; then

        log "Backup de GPU não encontrado."

        return

    fi


    log "Restaurando governors da GPU..."


    while IFS='|' read -r FILE VALUE; do

        if [ -n "$FILE" ] && [ -n "$VALUE" ]; then

            if [ -f "$FILE" ] && [ -w "$FILE" ]; then

                echo "$VALUE" > "$FILE" 2>/dev/null

                log "GPU restaurada: $FILE -> $VALUE"

            fi

        fi

    done < "$GPU_BACKUP"

}


###############################################################################
# DESATIVA FIXED PERFORMANCE
###############################################################################

disable_fixed_performance() {

    log "Desativando Fixed Performance Mode..."

    cmd power set-fixed-performance-mode-enabled false \
        >/dev/null 2>&1

}


###############################################################################
# RESTAURA GAME MODE
###############################################################################

restore_game_mode() {

    log "Procurando jogo atualmente em primeiro plano..."

    PKG=""

    PKG="$(dumpsys activity activities 2>/dev/null \
        | grep -m1 'mResumedActivity' \
        | sed -n 's/.* u[0-9]\+ \([^/ ]\+\)\/.*/\1/p')"


    if [ -n "$PKG" ]; then

        log "Pacote em primeiro plano: $PKG"

        cmd game mode standard "$PKG" \
            >/dev/null 2>&1

    fi

}


###############################################################################
# NÃO FORÇA BATTERY SAVER
###############################################################################
#
# O plugin não deve decidir se o usuário quer ou não economia de energia
# depois de ser removido.
#
# Portanto, não fazemos:
#
# settings put global low_power 0
#
# Isso evita alterar uma preferência pessoal durante a desinstalação.
###############################################################################


###############################################################################
# RESTAURA GOVERNORS
###############################################################################

restore_cpu
restore_gpu


###############################################################################
# DESATIVA PERFORMANCE MODE
###############################################################################

disable_fixed_performance

restore_game_mode


###############################################################################
# REMOVE ESTADO DO PLUGIN
###############################################################################

log "Removendo arquivos de estado..."

rm -f "$BASE_DIR/state" 2>/dev/null
rm -f "$BASE_DIR/cpu_governors" 2>/dev/null
rm -f "$BASE_DIR/gpu_governors" 2>/dev/null
rm -f "$BASE_DIR/last_cleanup" 2>/dev/null
rm -f "$BASE_DIR/game_boost_last" 2>/dev/null
rm -f "$BASE_DIR/previous_low_power" 2>/dev/null
rm -f "$BASE_DIR/installed" 2>/dev/null


###############################################################################
# NÃO APAGA:
#
# /data/
# /sdcard/
# /storage/emulated/0/
# Android/data/
# Android/obb/
# mundos do Minecraft
# configurações dos jogos
# fotos
# vídeos
# documentos
###############################################################################


###############################################################################
# REMOVE DIRETÓRIO
###############################################################################

rmdir "$BASE_DIR" 2>/dev/null


###############################################################################
# FINAL
###############################################################################

echo ""
echo "=============================================="
echo "      AX EXTREME ENGINE REMOVIDO"
echo "=============================================="
echo ""

exit 0