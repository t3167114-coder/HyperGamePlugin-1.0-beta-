#!/system/bin/sh
# ==============================================================================
#  HYPER GAME PLUGIN - UNINSTALL.SH
#  Autor: Tech_Android
# ==============================================================================

# Função auxiliar para redefinir valores de kernel com segurança
write() {
    if [ -e "$1" ]; then
        chmod 666 "$1" 2>/dev/null
        echo "$2" > "$1" 2>/dev/null
    fi
}

# ------------------------------------------------------------------------------
# 1. RESTAURAR CPU GOVERNOR PADRÃO (SCHEDUTIL / INTERACTIVE)
# ------------------------------------------------------------------------------
# Retorna os governors para o modo de economia/equilíbrio padrão do Android
for gov in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
    write "$gov" "schedutil" 2>/dev/null || write "$gov" "interactive" 2>/dev/null
done

# Restaurar read_ahead_kb padrão do armazenamento (128 KB)
for ra in /sys/block/*/queue/read_ahead_kb; do
    write "$ra" "128" 2>/dev/null
done

# Restaurar swappiness padrão
write "/proc/sys/vm/swappiness" "60" 2>/dev/null

# ------------------------------------------------------------------------------
# 2. LIMPEZA DE ARQUIVOS TEMPORÁRIOS E LOGS
# ------------------------------------------------------------------------------
# Remove quaisquer arquivos de log ou temporários criados pelo plugin
rm -rf /data/local/tmp/hypergame_*.log 2>/dev/null
rm -rf /sdcard/HyperGamePlugin 2>/dev/null

exit 0
