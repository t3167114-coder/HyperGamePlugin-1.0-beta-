#!/system/bin/sh
# ==============================================================================
#  AX MANAGER - ULTRA GAMING PERFORMANCE SERVICE.SH
# ==============================================================================
MODDIR=${0%/*}

# Função auxiliar para aplicar valores com segurança em nós do kernel
write() {
    if [ -e "$1" ]; then
        chmod 666 "$1" 2>/dev/null
        echo "$2" > "$1" 2>/dev/null
        chmod 444 "$1" 2>/dev/null
    fi
}

# Aguarda a inicialização completa do sistema
while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 3
done
sleep 5 # Margem de segurança para estabilização de serviços

# ------------------------------------------------------------------------------
# 1. FORÇAR TODOS OS NÚCLEOS DA CPU ONLINE & GOVERNOR PERFORMANCE
# ------------------------------------------------------------------------------
# Desativa controles de economia para manter todos os núcleos ativos
write "/sys/module/msm_performance/parameters/cpu_max_freq" "max"
write "/sys/module/control_center/parameters/boot_ref_ns" "0"

for cpu in /sys/devices/system/cpu/cpu*/online; do
    write "$cpu" "1"
done

for gov in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
    write "$gov" "performance"
done

# ------------------------------------------------------------------------------
# 2. UCLAMP / SCHEDTUNE (Prioridade Máxima para o Jogo / Top-App)
# ------------------------------------------------------------------------------
# Garante que a aplicação em primeiro plano (o jogo) rode nos núcleos mais rápidos
write "/dev/stune/top-app/schedtune.boost" "100"
write "/dev/stune/top-app/schedtune.prefer_idle" "1"
write "/dev/stune/foreground/schedtune.boost" "50"

# Otimização UCLAMP (Presente em Kernels mais recentes 5.x / 6.x)
write "/dev/cpuctl/top-app/cpu.uclamp.min" "100"
write "/dev/cpuctl/top-app/cpu.uclamp.latency_sensitive" "1"
write "/dev/cpuctl/foreground/cpu.uclamp.min" "50"

# ------------------------------------------------------------------------------
# 3. OTIMIZAÇÃO DE GPU (DESEMPENHO GRÁFICO E FREQUÊNCIA MÁXIMA)
# ------------------------------------------------------------------------------
# Qualcomm Adreno / ARM Mali
for gpu_gov in /sys/class/kgsl/kgsl-3d0/devfreq/governor \
               /sys/devices/platform/*.mali/devfreq/*.mali/governor \
               /sys/class/devfreq/*.gpu/governor; do
    write "$gpu_gov" "performance"
done

# Força clock máximo da GPU e desativa recursos de economia de energia
write "/sys/class/kgsl/kgsl-3d0/force_pwrlevel" "0"
write "/sys/class/kgsl/kgsl-3d0/force_bus_on" "1"
write "/sys/class/kgsl/kgsl-3d0/force_clk_on" "1"
write "/sys/class/kgsl/kgsl-3d0/idle_timer" "10000"

# ------------------------------------------------------------------------------
# 4. GERENCIAMENTO AVANÇADO DE MEMÓRIA (EVITA ENGASGOS / STUTTERING)
# ------------------------------------------------------------------------------
# Reduz a troca para ZRAM/Swap e prioriza retenção de cache de arquivos em RAM
write "/proc/sys/vm/swappiness" "0"
write "/proc/sys/vm/vfs_cache_pressure" "50"
write "/proc/sys/vm/dirty_ratio" "20"
write "/proc/sys/vm/dirty_background_ratio" "5"
write "/proc/sys/vm/compaction_proactiveness" "0"

# Libera RAM suja acumulada antes de abrir jogos
sync
write "/proc/sys/vm/drop_caches" "3"

# ------------------------------------------------------------------------------
# 5. AFINAMENTO DE I/O E ARMAZENAMENTO (CARREGAMENTO RÁPIDO DE MAPAS)
# ------------------------------------------------------------------------------
for queue in /sys/block/*/queue; do
    write "$queue/scheduler" "noop"
    write "$queue/read_ahead_kb" "2048"
    write "$queue/add_random" "0"
    write "$queue/iostats" "0"
    write "$queue/nomerges" "2"
    write "$queue/nr_requests" "256"
done

# ------------------------------------------------------------------------------
# 6. PROPRIEDADES DO SISTEMA (PROPS - SURFACEFLINGER E RENDERIZAÇÃO HWUI)
# ------------------------------------------------------------------------------
# Força renderização contínua de quadros via hardware sem aguardar sinais vagos
setprop debug.sf.latch_unsignaled 1
setprop debug.sf.enable_hwc_vds 1
setprop debug.sf.early_app_phase_offset_ns 5000000
setprop debug.sf.early_gl_app_phase_offset_ns 15000000
setprop debug.egl.hw 1
setprop debug.performance.tuning 1

# Aloca cache gráfico maior no pipeline do Android (HWUI)
setprop ro.hwui.texture_cache_size 88
setprop ro.hwui.layer_cache_size 58
setprop ro.hwui.path_cache_size 32
setprop ro.hwui.shape_cache_size 8
setprop ro.hwui.drop_shadow_cache_size 10

# ------------------------------------------------------------------------------
# 7. MITIGAÇÃO BÁSICA DE MITIGAÇÃO TÉRMICA (THERMAL CONTROL)
# ------------------------------------------------------------------------------
# Desativa limitações de freq por thermal throttling no kernel se acessível
write "/sys/module/msm_thermal/core_control/enabled" "0"
write "/sys/module/msm_thermal/parameters/enabled" "N"
