#!/system/bin/sh

###############################################################################
# AX EXTREME ENGINE
# Tech_Android
# @Tech_AndroidPRO
###############################################################################

MODDIR="${0%/*}"
CONFIG="$MODDIR/service.prop"

PLUGIN_NAME="AX Extreme Engine"
PLUGIN_AUTHOR="Tech_Android"
PLUGIN_DEVELOPER="@Tech_AndroidPRO"

###############################################################################
# CONFIGURAÇÃO PADRÃO
#
# Se uma propriedade não existir no service.prop, estes valores serão usados.
###############################################################################

service_enabled=true
service_autostart=true
service_delay=20
service_interval=15

performance_enabled=true
performance_cpu=true
performance_gpu=true
performance_fixed_mode=true

game_mode=true
game_mode_type=performance

memory_enabled=true
memory_game_cleanup=true
memory_background_cleanup=true
memory_cache_trim=true
memory_cleanup_cooldown=300
memory_cache_trim_size=1G

battery_dynamic=true
battery_critical=10
battery_low=20
battery_balanced=40
battery_high=65
battery_ultra=80

battery_game_disable_saver=true
battery_critical_enable_saver=true

thermal_guard_enabled=true
thermal_warning=42
thermal_high=44
thermal_critical=47

game_detection=true
game_auto_boost=true
game_auto_restore=true
game_auto_memory_cleanup=true

logging_enabled=true
logging_verbose=true
logging_max_size=524288

failsafe_enabled=true
failsafe_restore_governors=true
failsafe_restore_power_mode=true

compatibility_best_effort=true


###############################################################################
# LEITOR DE PROPRIEDADES
###############################################################################
#
# Converte:
#
# performance.cpu=true
#
# para:
#
# performance_cpu=true
#
###############################################################################

load_config() {

    if [ ! -f "$CONFIG" ]; then
        return
    fi

    while IFS='=' read -r KEY VALUE; do

        # Remove espaços
        KEY="$(echo "$KEY" | sed 's/[[:space:]]//g')"
        VALUE="$(echo "$VALUE" | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')"

        # Ignora linhas vazias
        [ -z "$KEY" ] && continue

        # Ignora comentários
        case "$KEY" in
            \#*)
                continue
                ;;
        esac

        # Ignora linhas que não possuem valor
        [ -z "$VALUE" ] && continue

        # Converte ponto em underscore
        VAR="$(echo "$KEY" | tr '.' '_')"

        # Permite somente nomes seguros
        case "$VAR" in
            *[!a-zA-Z0-9_]*)
                continue
                ;;
        esac

        # Exporta configuração
        eval "${VAR}=\"\$VALUE\""

    done < "$CONFIG"
}


###############################################################################
# CARREGA CONFIGURAÇÃO
###############################################################################

load_config


###############################################################################
# LOG
###############################################################################

BASE_DIR="/data/local/tmp/ax_extreme"

LOG_FILE="$BASE_DIR/ax_extreme.log"
STATE_FILE="$BASE_DIR/state"
CPU_BACKUP="$BASE_DIR/cpu_governors"
GPU_BACKUP="$BASE_DIR/gpu_governors"

mkdir -p "$BASE_DIR" 2>/dev/null
touch "$LOG_FILE" 2>/dev/null


log() {

    [ "$logging_enabled" = "true" ] || return

    MSG="$1"

    echo "[$(date '+%H:%M:%S')] $MSG" \
        >> "$LOG_FILE" 2>/dev/null
}


###############################################################################
# EXECUÇÃO SEGURA
###############################################################################

run_safe() {

    "$@" >/dev/null 2>&1

    return 0
}


###############################################################################
# INFORMAÇÕES DO SISTEMA
###############################################################################

ANDROID_VERSION="$(getprop ro.build.version.release 2>/dev/null)"
ANDROID_SDK="$(getprop ro.build.version.sdk 2>/dev/null)"
MODEL="$(getprop ro.product.model 2>/dev/null)"
DEVICE="$(getprop ro.product.device 2>/dev/null)"
BRAND="$(getprop ro.product.brand 2>/dev/null)"

log "=========================================="
log "$PLUGIN_NAME"
log "=========================================="
log "Modelo: $BRAND $MODEL"
log "Device: $DEVICE"
log "Android: $ANDROID_VERSION"
log "SDK: $ANDROID_SDK"
log "Configuração: $CONFIG"
log "=========================================="


###############################################################################
# SERVIÇO DESATIVADO
###############################################################################

if [ "$service_enabled" != "true" ]; then

    log "Serviço desativado pelo service.prop."

    exit 0

fi


###############################################################################
# BATERIA
###############################################################################

get_battery_level() {

    LEVEL="$(dumpsys battery 2>/dev/null \
        | grep -m1 'level:' \
        | tr -cd '0-9')"

    [ -n "$LEVEL" ] || LEVEL=50

    echo "$LEVEL"
}


get_battery_temp_raw() {

    TEMP="$(dumpsys battery 2>/dev/null \
        | grep -m1 'temperature:' \
        | tr -cd '0-9')"

    [ -n "$TEMP" ] || TEMP=300

    echo "$TEMP"
}


get_battery_temp() {

    RAW="$(get_battery_temp_raw)"

    echo "$RAW" | awk '{printf "%.1f\n", $1/10}'
}


###############################################################################
# BATTERY SAVER
###############################################################################

get_low_power() {

    VALUE="$(settings get global low_power 2>/dev/null)"

    case "$VALUE" in
        1)
            echo 1
            ;;
        *)
            echo 0
            ;;
    esac
}


disable_power_save() {

    [ "$battery_game_disable_saver" = "true" ] || return

    log "Desativando economia de energia para jogo."

    settings put global low_power 0 2>/dev/null

    run_safe cmd power set-mode 0
}


enable_power_save() {

    [ "$battery_critical_enable_saver" = "true" ] || return

    log "Ativando economia de energia."

    settings put global low_power 1 2>/dev/null

    run_safe cmd power set-mode 1
}


###############################################################################
# ANIMAÇÕES
###############################################################################

set_animation_profile() {

    PROFILE="$1"

    case "$PROFILE" in

        ULTRA|HIGH|BALANCED)

            settings put global animator_duration_scale 1.0 2>/dev/null
            settings put global transition_animation_scale 1.0 2>/dev/null
            settings put global window_animation_scale 1.0 2>/dev/null

            ;;

        BATTERY)

            settings put global animator_duration_scale 1.0 2>/dev/null
            settings put global transition_animation_scale 1.0 2>/dev/null
            settings put global window_animation_scale 1.0 2>/dev/null

            ;;

    esac
}


###############################################################################
# CPU BACKUP
###############################################################################

backup_cpu_governors() {

    : > "$CPU_BACKUP" 2>/dev/null

    for GOV in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor
    do

        if [ -f "$GOV" ]; then

            VALUE="$(cat "$GOV" 2>/dev/null)"

            [ -n "$VALUE" ] && \
                echo "$GOV|$VALUE" >> "$CPU_BACKUP"

        fi

    done
}


###############################################################################
# CPU PERFORMANCE
###############################################################################

set_cpu_performance() {

    [ "$performance_enabled" = "true" ] || return
    [ "$performance_cpu" = "true" ] || return

    log "Tentando CPU governor performance."

    FOUND=0

    for GOV in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor
    do

        if [ -f "$GOV" ] && [ -w "$GOV" ]; then

            echo performance > "$GOV" 2>/dev/null

            if [ "$(cat "$GOV" 2>/dev/null)" = "performance" ]; then
                FOUND=1
            fi

        fi

    done

    if [ "$FOUND" = "1" ]; then
        log "CPU governor performance aplicado."
    else
        log "CPU governor não pode ser alterado."
    fi
}


###############################################################################
# RESTORE CPU
###############################################################################

restore_cpu_governors() {

    [ "$failsafe_restore_governors" = "true" ] || return

    [ -f "$CPU_BACKUP" ] || return

    while IFS='|' read -r FILE VALUE
    do

        if [ -f "$FILE" ] && [ -w "$FILE" ]; then
            echo "$VALUE" > "$FILE" 2>/dev/null
        fi

    done < "$CPU_BACKUP"

    log "CPU restaurada."
}


###############################################################################
# GPU BACKUP
###############################################################################

backup_gpu_governors() {

    : > "$GPU_BACKUP" 2>/dev/null

    for GOV in \
        /sys/class/devfreq/*/governor \
        /sys/devices/platform/*devfreq*/devfreq/*/governor \
        /sys/devices/platform/*gpu*/devfreq/*/governor \
        /sys/class/kgsl/kgsl-3d0/devfreq/governor
    do

        if [ -f "$GOV" ]; then

            VALUE="$(cat "$GOV" 2>/dev/null)"

            [ -n "$VALUE" ] && \
                echo "$GOV|$VALUE" >> "$GPU_BACKUP"

        fi

    done
}


###############################################################################
# GPU PERFORMANCE
###############################################################################

set_gpu_performance() {

    [ "$performance_enabled" = "true" ] || return
    [ "$performance_gpu" = "true" ] || return

    log "Tentando GPU/devfreq performance."

    FOUND=0

    for GOV in \
        /sys/class/devfreq/*/governor \
        /sys/devices/platform/*devfreq*/devfreq/*/governor \
        /sys/devices/platform/*gpu*/devfreq/*/governor \
        /sys/class/kgsl/kgsl-3d0/devfreq/governor
    do

        if [ -f "$GOV" ] && [ -w "$GOV" ]; then

            echo performance > "$GOV" 2>/dev/null

            if [ "$(cat "$GOV" 2>/dev/null)" = "performance" ]; then
                FOUND=1
            fi

        fi

    done

    [ "$FOUND" = "1" ] && \
        log "GPU governor performance aplicado."
}


###############################################################################
# RESTORE GPU
###############################################################################

restore_gpu_governors() {

    [ "$failsafe_restore_governors" = "true" ] || return

    [ -f "$GPU_BACKUP" ] || return

    while IFS='|' read -r FILE VALUE
    do

        if [ -f "$FILE" ] && [ -w "$FILE" ]; then
            echo "$VALUE" > "$FILE" 2>/dev/null
        fi

    done < "$GPU_BACKUP"

    log "GPU restaurada."
}


###############################################################################
# FIXED PERFORMANCE
###############################################################################

enable_fixed_performance() {

    [ "$performance_enabled" = "true" ] || return
    [ "$performance_fixed_mode" = "true" ] || return

    run_safe cmd power \
        set-fixed-performance-mode-enabled true

    log "Fixed Performance solicitado."
}


disable_fixed_performance() {

    [ "$performance_fixed_mode" = "true" ] || return

    run_safe cmd power \
        set-fixed-performance-mode-enabled false

}


###############################################################################
# FOREGROUND APP
###############################################################################

get_foreground_package() {

    PKG=""

    PKG="$(dumpsys activity activities 2>/dev/null \
        | grep -m1 'mResumedActivity' \
        | sed -n \
        's/.* u[0-9]\+ \([^/ ]\+\)\/.*/\1/p')"

    if [ -z "$PKG" ]; then

        PKG="$(dumpsys window 2>/dev/null \
            | grep -m1 'mCurrentFocus' \
            | sed -n \
            's/.*u0 \([^/]*\)\/.*/\1/p')"

    fi

    echo "$PKG"
}


###############################################################################
# LISTA DE JOGOS
###############################################################################

GAME_PACKAGES="
com.roblox.client
com.dts.freefireth
com.dts.freefiremax
com.pubg.imobile
com.tencent.ig
com.activision.callofduty.shooter
com.garena.game.codm
com.mojang.minecraftpe
com.epicgames.fortnite
com.miHoYo.GenshinImpact
com.HoYoverse.hkrpgoversea
com.supercell.clashofclans
com.supercell.clashroyale
com.supercell.brawlstars
com.mobile.legends
com.riotgames.league.wildrift
"


###############################################################################
# GAME DETECTION
###############################################################################

is_known_game() {

    TARGET="$1"

    for GAME in $GAME_PACKAGES
    do

        [ "$TARGET" = "$GAME" ] && return 0

    done

    return 1
}


is_game_heuristic() {

    TARGET="$1"

    case "$TARGET" in

        *roblox*|\
        *freefire*|\
        *free.fire*|\
        *pubg*|\
        *minecraft*|\
        *genshin*|\
        *honkai*|\
        *fortnite*|\
        *callofduty*|\
        *mobilelegends*|\
        *brawlstars*|\
        *clashofclans*|\
        *clashroyale*|\
        *wildrift*|\
        *asphalt*)

            return 0
            ;;

    esac

    return 1
}


is_android_game() {

    TARGET="$1"

    [ -n "$TARGET" ] || return 1

    dumpsys package "$TARGET" 2>/dev/null \
        | grep -q 'android.intent.category.GAME'

}


is_game() {

    [ "$game_detection" = "true" ] || return 1

    TARGET="$1"

    [ -n "$TARGET" ] || return 1

    is_known_game "$TARGET" && return 0

    is_game_heuristic "$TARGET" && return 0

    is_android_game "$TARGET" && return 0

    return 1
}


###############################################################################
# LIMPEZA DE RAM
###############################################################################

clean_memory() {

    [ "$memory_enabled" = "true" ] || return
    [ "$memory_game_cleanup" = "true" ] || return

    log "Limpando processos em segundo plano."

    if [ "$memory_background_cleanup" = "true" ]; then

        run_safe am kill-all
        run_safe cmd activity kill-all

    fi

    sleep 2
}


###############################################################################
# CACHE
###############################################################################

trim_app_caches() {

    [ "$memory_enabled" = "true" ] || return
    [ "$memory_cache_trim" = "true" ] || return

    log "Executando trim de caches."

    run_safe pm trim-caches "$memory_cache_trim_size"

    run_safe cmd package trim-caches \
        "$memory_cache_trim_size"

}


###############################################################################
# GAME MEMORY CLEANUP
###############################################################################

game_memory_cleanup() {

    [ "$game_auto_memory_cleanup" = "true" ] || return

    NOW="$(date +%s)"

    if [ -f "$BASE_DIR/last_cleanup" ]; then
        LAST="$(cat "$BASE_DIR/last_cleanup" 2>/dev/null)"
    else
        LAST=0
    fi

    DIFF=$((NOW - LAST))

    if [ "$DIFF" -lt "$memory_cleanup_cooldown" ]; then

        log "Cooldown de limpeza ativo."

        return

    fi

    clean_memory

    sleep 1

    trim_app_caches

    echo "$NOW" > "$BASE_DIR/last_cleanup"

    log "Limpeza de memória concluída."
}


###############################################################################
# GAME MODE
###############################################################################

enable_game_mode() {

    GAME="$1"

    [ "$game_mode" = "true" ] || return
    [ -n "$GAME" ] || return

    log "Game Mode: $game_mode_type -> $GAME"

    run_safe cmd game mode \
        "$game_mode_type" "$GAME"

}


disable_game_mode() {

    GAME="$1"

    [ "$game_mode" = "true" ] || return
    [ -n "$GAME" ] || return

    run_safe cmd game mode standard "$GAME"

}


###############################################################################
# ENTER GAME
###############################################################################

CURRENT_GAME=""

enter_game() {

    GAME="$1"

    [ -n "$GAME" ] || return

    CURRENT_GAME="$GAME"

    log "=========================================="
    log "GAME BOOST ATIVADO"
    log "Jogo: $GAME"
    log "=========================================="


    ###########################################################################
    # BACKUPS
    ###########################################################################

    backup_cpu_governors
    backup_gpu_governors


    ###########################################################################
    # BATTERY SAVER
    ###########################################################################

    disable_power_save


    ###########################################################################
    # GAME MODE
    ###########################################################################

    enable_game_mode "$GAME"


    ###########################################################################
    # PERFORMANCE
    ###########################################################################

    set_cpu_performance
    set_gpu_performance
    enable_fixed_performance


    ###########################################################################
    # MEMORY
    ###########################################################################

    game_memory_cleanup

}


###############################################################################
# EXIT GAME
###############################################################################

exit_game() {

    GAME="$CURRENT_GAME"

    [ -n "$GAME" ] || return

    log "=========================================="
    log "GAME BOOST DESATIVADO"
    log "Jogo: $GAME"
    log "=========================================="


    disable_game_mode "$GAME"

    disable_fixed_performance

    restore_cpu_governors
    restore_gpu_governors

    CURRENT_GAME=""

}


###############################################################################
# THERMAL GUARD
###############################################################################

thermal_guard() {

    [ "$thermal_guard_enabled" = "true" ] || return

    TEMP="$1"

    TEMP_INT="${TEMP%.*}"


    ###########################################################################
    # WARNING
    ###########################################################################

    if [ "$TEMP_INT" -ge "$thermal_warning" ]; then

        log "Temperatura elevada: ${TEMP}C"

        disable_fixed_performance

    fi


    ###########################################################################
    # HIGH
    ###########################################################################

    if [ "$TEMP_INT" -ge "$thermal_high" ]; then

        log "Temperatura alta: ${TEMP}C"

        restore_cpu_governors
        restore_gpu_governors

    fi


    ###########################################################################
    # CRITICAL
    ###########################################################################

    if [ "$TEMP_INT" -ge "$thermal_critical" ]; then

        log "TEMPERATURA CRÍTICA: ${TEMP}C"

        disable_fixed_performance

        restore_cpu_governors
        restore_gpu_governors

        enable_power_save

    fi

}


###############################################################################
# BATTERY PROFILE
###############################################################################

CURRENT_PROFILE=""

apply_battery_profile() {

    [ "$battery_dynamic" = "true" ] || return

    [ -n "$CURRENT_GAME" ] && return

    LEVEL="$(get_battery_level)"

    PROFILE="BALANCED"

    if [ "$LEVEL" -le "$battery_critical" ]; then
        PROFILE="CRITICAL"
    elif [ "$LEV