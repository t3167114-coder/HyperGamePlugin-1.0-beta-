#!/system/bin/sh

###############################################################################
# AX EXTREME ENGINE
# CUSTOMIZE / INSTALL SCRIPT
###############################################################################

MODDIR="${0%/*}"

PLUGIN_NAME="AX Extreme Engine"
VERSION="1.0.0"

BASE_DIR="/data/local/tmp/ax_extreme"

LOG_FILE="$BASE_DIR/install.log"


###############################################################################
# FUNÇÕES
###############################################################################

log() {
    echo "[AX EXTREME] $1"

    mkdir -p "$BASE_DIR" 2>/dev/null

    echo "[$(date '+%H:%M:%S')] $1" >> "$LOG_FILE" 2>/dev/null
}


###############################################################################
# INÍCIO
###############################################################################

echo ""
echo "=============================================="
echo "        AX EXTREME ENGINE"
echo "        Installation Script"
echo "=============================================="
echo ""

log "Iniciando instalação..."
log "Versão: $VERSION"
log "Diretório: $MODDIR"


###############################################################################
# VERIFICA ANDROID
###############################################################################

ANDROID_VERSION="$(getprop ro.build.version.release 2>/dev/null)"
ANDROID_SDK="$(getprop ro.build.version.sdk 2>/dev/null)"

log "Android: $ANDROID_VERSION"
log "SDK: $ANDROID_SDK"


###############################################################################
# VERIFICA ADB
###############################################################################

if command -v settings >/dev/null 2>&1; then
    log "Comando settings: OK"
else
    log "AVISO: settings não encontrado."
fi


if command -v dumpsys >/dev/null 2>&1; then
    log "Comando dumpsys: OK"
else
    log "AVISO: dumpsys não encontrado."
fi


if command -v am >/dev/null 2>&1; then
    log "Comando am: OK"
else
    log "AVISO: am não encontrado."
fi


if command -v pm >/dev/null 2>&1; then
    log "Comando pm: OK"
else
    log "AVISO: pm não encontrado."
fi


###############################################################################
# CRIA DIRETÓRIO DE ESTADO
###############################################################################

if mkdir -p "$BASE_DIR" 2>/dev/null; then

    log "Diretório de estado criado."

else

    log "AVISO: não foi possível criar $BASE_DIR."

fi


###############################################################################
# CRIA ARQUIVOS DE ESTADO
###############################################################################

touch "$BASE_DIR/state" 2>/dev/null
touch "$BASE_DIR/cpu_governors" 2>/dev/null
touch "$BASE_DIR/gpu_governors" 2>/dev/null
touch "$BASE_DIR/last_cleanup" 2>/dev/null
touch "$BASE_DIR/game_boost_last" 2>/dev/null


###############################################################################
# PERMISSÕES
###############################################################################

if [ -f "$MODDIR/service.sh" ]; then

    chmod 755 "$MODDIR/service.sh" 2>/dev/null

    log "Permissão do service.sh configurada."

else

    log "ERRO: service.sh não encontrado."

fi


###############################################################################
# PROPRIEDADES
###############################################################################

if [ -f "$MODDIR/service.prop" ]; then

    chmod 644 "$MODDIR/service.prop" 2>/dev/null

    log "service.prop encontrado."

else

    log "AVISO: service.prop não encontrado."

fi


###############################################################################
# VERIFICA ARQUIVOS
###############################################################################

MISSING=0


if [ ! -f "$MODDIR/service.sh" ]; then
    log "FALTANDO: service.sh"
    MISSING=1
fi


if [ ! -f "$MODDIR/service.prop" ]; then
    log "FALTANDO: service.prop"
    MISSING=1
fi


###############################################################################
# INFORMAÇÕES DO APARELHO
###############################################################################

MODEL="$(getprop ro.product.model 2>/dev/null)"
DEVICE="$(getprop ro.product.device 2>/dev/null)"
BRAND="$(getprop ro.product.brand 2>/dev/null)"

log "Fabricante: $BRAND"
log "Modelo: $MODEL"
log "Codename: $DEVICE"


###############################################################################
# VERIFICA ROOT
###############################################################################

UID="$(id -u 2>/dev/null)"

if [ "$UID" = "0" ]; then

    log "Modo ROOT detectado."

else

    log "Modo não-root/ADB detectado."

fi


###############################################################################
# CRIA ARQUIVO DE INSTALAÇÃO
###############################################################################

cat > "$BASE_DIR/installed" <<EOF
plugin=AX Extreme Engine
version=$VERSION
installed=$(date '+%Y-%m-%d %H:%M:%S')
android=$ANDROID_VERSION
sdk=$ANDROID_SDK
model=$MODEL
device=$DEVICE
EOF


###############################################################################
# FINAL
###############################################################################

if [ "$MISSING" = "0" ]; then

    log "Todos os arquivos principais estão presentes."
    log "Instalação preparada com sucesso."

else

    log "Instalação incompleta: existem arquivos ausentes."

fi


echo ""
echo "=============================================="
echo " Instalação finalizada"
echo "=============================================="
echo ""

exit 0