#!/system/bin/sh
# ==============================================================================
#  HYPER GAME PLUGIN - CUSTOMIZE.SH
#  Autor: Tech_Android
# ==============================================================================

# Impede a extração automática padrão para que possamos controlar o processo
SKIPUNZIP=1

ui_print "==========================================="
ui_print "        HYPER GAME PLUGIN - V1.0           "
ui_print "     Otimização Suprema para Jogos         "
ui_print "==========================================="
ui_print "  • Desenvolvedor : Tech_Android"
ui_print "  • Suporte        : AX Manager / Magisk / KSU"
ui_print "==========================================="

# Detecta e exibe informações do sistema
ui_print "- Verificando ambiente do dispositivo..."
ui_print "  • Arquitetura CPU : $ARCH"
ui_print "  • Nível de API    : $API"

# Extrai os arquivos do pacote ZIP para a pasta de instalação do módulo
ui_print "- Extraindo arquivos do plugin..."
unzip -o "$ZIPFILE" -x 'META-INF/*' -d "$MODPATH" >/dev/null

# Aplica as permissões padrão para pastas e arquivos (Diretórios: 0755 | Arquivos: 0644)
ui_print "- Aplicando permissões de arquivos..."
set_perm_recursive "$MODPATH" 0 0 0755 0644

# Garante permissão de execução (0755 / rwxr-xr-x) para os scripts do plugin
if [ -f "$MODPATH/service.sh" ]; then
    ui_print "  • Atribuindo permissão de execução em: service.sh"
    set_perm "$MODPATH/service.sh" 0 0 0755
fi

if [ -f "$MODPATH/action.sh" ]; then
    ui_print "  • Atribuindo permissão de execução em: action.sh"
    set_perm "$MODPATH/action.sh" 0 0 0755
fi

# Finalização da instalação
ui_print "==========================================="
ui_print "      INSTALAÇÃO CONCLUÍDA COM SUCESSO!    "
ui_print "==========================================="
ui_print "  • Criado por: Tech_Android"
ui_print "  • Reinicie o dispositivo para ativar o"
ui_print "    HyperGamePlugin."
ui_print "==========================================="
